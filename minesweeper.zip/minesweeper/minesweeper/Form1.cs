
using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {



        private readonly GameProcess gameProcess;
        public Form1()
        {
            InitializeComponent();

            dataGridView1.CellMouseClick += dataGridView1_CellContentClick;
            gameProcess = new GameProcess(dataGridView1, rows, columns, imgShow, restart);
            dataGridView1 = new DataGridView();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            gameProcess.Mouse(e);

        }

        private void rows_TextChanged(object sender, EventArgs e)
        {

        }


        private void columns_TextChanged(object sender, EventArgs e)
        {

        }

        private void start_Click(object sender, EventArgs e)
        {
            gameProcess.Startclick();
        }
        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void Check_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void imgShow_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void restart_Click(object sender, EventArgs e)
        {
            gameProcess.Startclick();
        }
    }
}
