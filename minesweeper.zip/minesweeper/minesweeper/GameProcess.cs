﻿using System.Drawing;
using System;
using System.Windows.Forms;
using System.Media;
using System.Threading.Tasks;
using System.Threading;
using System.Security.Policy;

namespace WindowsFormsApp3
{
    internal class GameProcess
    {
        private const int MINE = 1;
        private const int EMPTY = 0;
        private int[,] imgfield;
        private int[,] field;
        private int minesPlaced;
        private string imagePath = "";

        private SoundPlayer sound;
        private readonly System.Windows.Forms.DataGridView dataGridView1;
        public readonly System.Windows.Forms.TextBox rows;
        private readonly System.Windows.Forms.PictureBox imgShow;
        private readonly System.Windows.Forms.TextBox columns;
        private readonly System.Windows.Forms.Button restart;
        public GameProcess(DataGridView dataGridView, TextBox rowsTextBox, TextBox columnsTextBox, PictureBox imgShowPictureBox, Button restartButton)
        {
            dataGridView1 = dataGridView;
            rows = rowsTextBox;
            columns = columnsTextBox;
            imgShow = imgShowPictureBox;
            restart = restartButton;
        }
        //detects the mouse button and sends further to its functions
        //then checks if player wins or no with other function
        public void Mouse(DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                Mouseright(e);
                ShowWin();
            }
            if (e.Button == MouseButtons.Left && e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                Mouseleft(e);
                ShowWin();
            }
        }
        //left mouse button function
        private void Mouseleft(DataGridViewCellMouseEventArgs e)
        {

            //sets variables for rows and columns,
            //a boolean to check the first click
            //and a line with the number of mines around the clicked cell
            int row = e.RowIndex;
            int col = e.ColumnIndex;
            bool first = CheckForFirstClick();
            if (first)
            {
                //places mines taking into account the rules of the game
                //and the fact that the click is the first
                PlaceMines(field.GetLength(0), field.GetLength(1), row, col);
                //opens the cells around the pressed one
                //and around the empty ones (if any)
                Inturnof(row, col);
                //correctly places the number of mines on open cells
                //(if don’t do it again, there may be errors)
                AllOpenedWFirstClick();
            }
            //empty is a constant for cells without a mine;
            //if pressed, the corresponding functions are then executed
            if (field[row, col] == EMPTY)
            {
                //the function is responsible for opening the cell
                //and the correct picture
                OpenCell(row, col);

            }
            //if mine is pressed
            else if (field[row, col] == MINE)
            {
                //shows all mines
                RevealMines();
                //reproduces sound and video of the defeat
                ShowLose();
            }
        }
        //start button
        public void Startclick()
        {
            //hides elements that are now unnecessary
            restart.Visible = false;
            imgShow.Visible = false;
            int row = 0, column = 0;
            //converts input to a number;
            //if not a number is encountered, displays an error message
            try
            {
                row = int.Parse(rows.Text);
                column = int.Parse(columns.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Insert acceptable value of rows or columns: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            field = new int[row, column];

            imgfield = new int[row, column];
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            //creating a table,
            //putting the corresponding values ​​into a matrix
            //and placing pictures in each cell
            for (int i = 0; i < column; i++)
            {
                dataGridView1.Columns.Add("Column" + i + 1, "Column " + i);
                dataGridView1.Columns[i].Width = 20;
            }
            for (int j = 0; j < row; j++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[j].Height = 20;
            }
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    DataGridViewImageCell imageCell = new DataGridViewImageCell();
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "bg.jpeg");
                    Image originalImage = Image.FromFile(imagePath);
                    int newWidth = 20;
                    int newHeight = 20;
                    Image resizedImage = new Bitmap(originalImage, newWidth, newHeight);
                    imageCell.Value = resizedImage;

                    dataGridView1.Rows[i].Cells[j] = imageCell;
                    imgfield[i, j] = 0;
                }
            }
            //hide unnecessary capital lines and columns
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = false;
        }
        //right mouse button
        private void Mouseright(DataGridViewCellMouseEventArgs e)
        {
            //defines the pressed cell
            DataGridViewCell clickedCell = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];

            string imagePath;
            //since when placing the background image,
            //I placed the value 0 in the matrix,
            //if the clicked cell has a value of 0, I put a flag
            if (imgfield[clickedCell.RowIndex, clickedCell.ColumnIndex] == 0)
            {
                imagePath = System.IO.Path.Combine(Application.StartupPath, "flag.png");
                Image flagImage = Image.FromFile(imagePath);
                int newWidth = 20;
                int newHeight = 20;
                Image resizedImage = new Bitmap(flagImage, newWidth, newHeight);
                clickedCell.Value = resizedImage;
                imgfield[e.RowIndex, e.ColumnIndex] = 1;

            }
            //if it's a flag I return the background
            else if (imgfield[e.RowIndex, e.ColumnIndex] == 1)
            {
                imagePath = System.IO.Path.Combine(Application.StartupPath, "bg.jpeg");
                Image flagImage = Image.FromFile(imagePath);
                int newWidth = 20;
                int newHeight = 20;
                Image resizedImage = new Bitmap(flagImage, newWidth, newHeight);
                clickedCell.Value = resizedImage;
                imgfield[e.RowIndex, e.ColumnIndex] = 0;
            }
        }
        //mine placement
        private void PlaceMines(int rows, int columns, int row, int col)
        {
            //I take the values ​​of the pressed cell and the length and height of the matrix,
            //create a element of class Random
            //and as long as the total specified number of mines is less than the required one,
            //I continue the cycle
            int clickrow = row;
            int clickcol = col;
            Random random = new Random();
            int totalMines = (rows * columns) / 5;
            minesPlaced = 0;

            while (minesPlaced < totalMines)
            {
                int randomRow = random.Next(0, rows);
                int randomCol = random.Next(0, columns);
                bool around = Aroundcell(randomRow, randomCol, clickrow, clickcol);
                if (field[randomRow, randomCol] != MINE || /*a function that checks whether a random cell is 
                                                            * one of the cells around the pressed one */ around)
                {
                    field[randomRow, randomCol] = MINE; // Place a mine
                    minesPlaced++;
                }
            }
        }
        //a function that checks whether a random cell is 
        // one of the cells around the pressed one
        private bool Aroundcell(int randrow, int randcol, int clickrow, int clickcol)
        {
            bool around = true;
            int[,] offsets =
            {
                {-1, -1}, {-1, 0}, {-1, 1},
                {0, -1}, {0, 1}, {0, 0},
                {1, -1}, {1, 0}, {1, 1}
            };


            for (int i = 0; i < offsets.GetLength(0); i++)
            {
                int adjRow = clickrow + offsets[i, 0];
                int adjCol = clickcol + offsets[i, 1];
                //I check if there is a cell on the field
                if (IsValidCell(adjRow, adjCol) && field[adjRow, adjCol] == field[randrow, randcol])
                {
                    around = false;
                    break;
                }
            }
            return around;
        }
        //check if click is first
        private bool CheckForFirstClick()
        {
            bool first = true;
            for (int i = 0; i < imgfield.GetLength(0); i++)
            {
                for (int j = 0; j < imgfield.GetLength(1); j++)
                {
                    if (imgfield[i, j] == 2)
                    {
                        first = false;

                    }
                }
            }
            return first;
        }
        //check if all field if opened
        public bool CheckForOpenField()
        {
            int flagCount = 0;
            int closedCellCount = 0;

            for (int i = 0; i < field.GetLength(0); i++)
            {
                for (int j = 0; j < field.GetLength(1); j++)
                {
                    if (field[i, j] == MINE && imgfield[i, j] == 1)
                    {
                        flagCount++;
                    }

                    if (field[i, j] != MINE && imgfield[i, j] != 2)
                    {
                        closedCellCount++;
                    }
                }
            }
            CountPlacedMines();


            //checking the victory condition
            if (flagCount == minesPlaced && closedCellCount == 0)
            {
                return true;
            }

            return false;
        }
        //shows gif and play sound
        public void ShowLose()
        {
            try
            {
                string soundPath = System.IO.Path.Combine(Application.StartupPath, "losesound.wav");
                sound = new SoundPlayer(soundPath);
                sound.Play();
                imgShow.Visible = true;
                string gifPath = System.IO.Path.Combine(Application.StartupPath, "losehdghg.gif");
                Image gifImage = Image.FromFile(gifPath);
                imgShow.Image = gifImage;
                imgShow.SizeMode = PictureBoxSizeMode.Zoom;
                imgShow.Location = new Point(10, 10);
                imgShow.Size = new Size(430, 450);
                imgShow.BringToFront();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке GIF: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            restart.Visible = true;
        }
        //shows gif and play sound
        public void ShowWin()
        {
            if (CheckForOpenField())
            {
                try
                {
                    string soundPath = System.IO.Path.Combine(Application.StartupPath, "winsound.wav");
                    sound = new SoundPlayer(soundPath);
                    sound.Play();
                    imgShow.Visible = true;
                    string gifPath = System.IO.Path.Combine(Application.StartupPath, "wincat.gif");
                    Image gifImage = Image.FromFile(gifPath);
                    imgShow.Image = gifImage;
                    imgShow.SizeMode = PictureBoxSizeMode.Zoom;
                    imgShow.Location = new Point(10, 10);
                    imgShow.Size = new Size(430, 450);
                    imgShow.BringToFront();
                    restart.Visible = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке GIF: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

        }

        private void OpenCell(int row, int col)
        {

            DataGridViewCell cell = dataGridView1.Rows[row].Cells[col];
            cell.Value = GetCellValue(row, col);
            string quanmine = GetCellValue(row, col);

            //switch case for every possible number of
            //the world around the cell
            switch (quanmine)
            {
                case "0":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "zero.png");
                    Image zeroImage = Image.FromFile(imagePath);
                    int newWidth = 20;
                    int newHeight = 20;
                    Image resizedzeroImage = new Bitmap(zeroImage, newWidth, newHeight);
                    cell.Value = resizedzeroImage;
                    imgfield[row, col] = 2;
                    //call a function that opens the cells around
                    Inturnof(row, col);
                    break;
                case "1":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "one.png");
                    Image oneImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedoneImage = new Bitmap(oneImage, newWidth, newHeight);
                    cell.Value = resizedoneImage;
                    imgfield[row, col] = 2;
                    break;
                case "2":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "two.png");
                    Image twoImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedtwoImage = new Bitmap(twoImage, newWidth, newHeight);
                    cell.Value = resizedtwoImage;
                    imgfield[row, col] = 2;
                    break;
                case "3":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "three.png");
                    Image threeImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedthreeImage = new Bitmap(threeImage, newWidth, newHeight);
                    cell.Value = resizedthreeImage;
                    imgfield[row, col] = 2;
                    break;
                case "4":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "four.png");
                    Image fourImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedfourImage = new Bitmap(fourImage, newWidth, newHeight);
                    cell.Value = resizedfourImage;
                    imgfield[row, col] = 2;
                    break;
                case "5":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "five.png");
                    Image fiveImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedfiveImage = new Bitmap(fiveImage, newWidth, newHeight);
                    cell.Value = resizedfiveImage;
                    imgfield[row, col] = 2;
                    break;
                case "6":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "six.png");
                    Image sixImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedsixImage = new Bitmap(sixImage, newWidth, newHeight);
                    cell.Value = resizedsixImage;
                    imgfield[row, col] = 2;
                    break;
                case "7":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "seven.jpe");
                    Image sevenImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedsevenImage = new Bitmap(sevenImage, newWidth, newHeight);
                    cell.Value = resizedsevenImage;
                    imgfield[row, col] = 2;
                    break;
                case "8":
                    imagePath = System.IO.Path.Combine(Application.StartupPath, "eight.jpeg");
                    Image eightImage = Image.FromFile(imagePath);
                    newWidth = 20;
                    newHeight = 20;
                    Image resizedeightImage = new Bitmap(eightImage, newWidth, newHeight);
                    cell.Value = resizedeightImage;
                    imgfield[row, col] = 2;
                    break;

            }

        }
        //opens the cells around
        private void Inturnof(int row, int col)
        {

            int[,] offsets =
            {
                {-1, -1}, {-1, 0}, {-1, 1},
                {0, -1}, {0, 1}, {0, 0},
                {1, -1}, {1, 0}, {1, 1}
            };


            for (int i = 0; i < offsets.GetLength(0); i++)
            {
                int adjRow = row + offsets[i, 0];
                int adjCol = col + offsets[i, 1];
                //if the cell is empty again, call a function to open it
                if (IsValidCell(adjRow, adjCol) && imgfield[adjRow, adjCol] != 2)
                {
                    field[adjRow, adjCol] = EMPTY;
                    OpenCell(adjRow, adjCol);
                }
            }
        }
        //true if there is a cell on the field false if not
        private bool IsValidCell(int row, int col)
        {
            return row >= 0 && row < field.GetLength(0) &&
                   col >= 0 && col < field.GetLength(1);
        }
        //shows all mines in case of loss
        private void RevealMines()
        {
            for (int r = 0; r < field.GetLength(0); r++)
            {
                for (int c = 0; c < field.GetLength(1); c++)
                {
                    if (field[r, c] == MINE)
                    {
                        DataGridViewCell cell = dataGridView1.Rows[r].Cells[c];
                        string imagePath = System.IO.Path.Combine(Application.StartupPath, "mine.jpeg");
                        Image mineImage = Image.FromFile(imagePath);
                        int newWidth = 20;
                        int newHeight = 20;
                        Image resizedImage = new Bitmap(mineImage, newWidth, newHeight);
                        cell.Value = resizedImage;
                    }
                }
            }
        }
        //returns the number of mines around and whether the mine is pressed
        private string GetCellValue(int row, int col)
        {
            if (field[row, col] == MINE)
            {
                return "*";
            }
            else
            {
                int adjacentMines = CountAdjacentMines(row, col);
                return adjacentMines.ToString();
            }
        }
        //returns the number of mines around
        private int CountAdjacentMines(int row, int col)
        {
            int count = 0;


            int[,] offsets =
            {
                {-1, -1}, {-1, 0}, {-1, 1},
                {0, -1}, {0, 1},
                {1, -1}, {1, 0}, {1, 1}
            };

            for (int i = 0; i < offsets.GetLength(0); i++)
            {
                int adjRow = row + offsets[i, 0];
                int adjCol = col + offsets[i, 1];

                if (IsValidCell(adjRow, adjCol) && field[adjRow, adjCol] == MINE)
                {
                    count++;
                }
            }

            return count;
        }
        //rechecks the pictures of the cells opened by the first click
        //and arranges them correctly
        private void AllOpenedWFirstClick()
        {
            for (int i = 0; i < imgfield.GetLength(0); i++)
            {
                for (int j = 0; j < imgfield.GetLength(1); j++)
                {
                    if (imgfield[i, j] == 2)
                    {
                        OpenCell(i, j);
                    }
                }
            }
        }
        //recalculates the mines placed on the field, since sometimes 
        //it is not possible to fulfill the specified conditions
        private void CountPlacedMines()
        {
            minesPlaced = 0;
            for (int i = 0; i < imgfield.GetLength(0); i++)
            {
                for (int j = 0; j < imgfield.GetLength(1); j++)
                {
                    if (imgfield[i, j] == MINE)
                    {
                        minesPlaced++;
                    }
                }
            }
        }
    }
}